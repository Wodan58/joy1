/*
    module  : has.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef HAS_C
#define HAS_C

#include "compare.h"

/**
2300  has  :  A X  ->  B
Tests whether aggregate A has X as a member.
*/
INHAS(has_, "has", nextnode1(env->stck), env->stck)



#endif
