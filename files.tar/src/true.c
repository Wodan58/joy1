/*
    module  : true.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef TRUE_C
#define TRUE_C

/**
1010  true  :  ->  true
Pushes the value true.
*/
PUSH(true_, BOOLEAN_NEWNODE, 1)



#endif
