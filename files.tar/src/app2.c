/*
    module  : app2.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef APP2_C
#define APP2_C

/**
2550  app2  :  X1 X2 [P]  ->  R1 R2
Obsolescent.  ==  unary2
*/
PRIVATE void app2_(pEnv env) { unary2_(env); }



#endif
