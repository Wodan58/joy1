/*
    module  : rand.c
    version : 1.2
    date    : 04/11/22
*/
#ifndef RAND_C
#define RAND_C

/**
1150  rand  :  ->  I
I is a random integer.
*/
PUSH(rand_, INTEGER_NEWNODE, rand())



#endif
