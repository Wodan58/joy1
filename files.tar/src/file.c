/*
    module  : file.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef FILE_C
#define FILE_C

/**
2420  file  :  F  ->  B
Tests whether F is a file.
*/
TYPE(file_, "file", ==, FILE_)



#endif
