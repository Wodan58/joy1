/*
    module  : ord.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef ORD_C
#define ORD_C

/**
1460  ord  :  C  ->  I
Integer I is the Ascii value of character C (or logical or integer).
*/
ORDCHR(ord_, "ord", INTEGER_NEWNODE)



#endif
