/*
    module  : cos.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef COS_C
#define COS_C

/**
1540  cos  :  F  ->  G
G is the cosine of F.
*/
UFLOAT(cos_, "cos", cos)



#endif
