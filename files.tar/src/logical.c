/*
    module  : logical.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef LOGICAL_C
#define LOGICAL_C

/**
2350  logical  :  X  ->  B
Tests whether X is a logical.
*/
TYPE(logical_, "logical", ==, BOOLEAN_)



#endif
