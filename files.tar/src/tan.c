/*
    module  : tan.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef TAN_C
#define TAN_C

/**
1670  tan  :  F  ->  G
G is the tangent of F.
*/
UFLOAT(tan_, "tan", tan)



#endif
