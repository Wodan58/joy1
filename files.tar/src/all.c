/*
    module  : all.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef ALL_C
#define ALL_C

/**
2880  all  :  A [B]  ->  X
Applies test B to members of aggregate A, X = true if all pass.
*/
SOMEALL(all_, "all", 1)



#endif
