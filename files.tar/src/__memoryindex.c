/*
    module  : __memoryindex.c
    version : 1.2
    date    : 05/03/22
*/
#ifndef __MEMORYINDEX_C
#define __MEMORYINDEX_C

/**
3080  __memoryindex  :  ->  I
Pushes current value of memory.
*/
PUBLIC void __memoryindex_(pEnv env)
{
    my_memoryindex(env);
}
#endif
