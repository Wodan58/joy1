/*
    module  : cosh.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef COSH_C
#define COSH_C

/**
1550  cosh  :  F  ->  G
G is the hyperbolic cosine of F.
*/
UFLOAT(cosh_, "cosh", cosh)



#endif
