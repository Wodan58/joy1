/*
    module  : __dump.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef __DUMP_C
#define __DUMP_C

/**
1070  __dump  :  ->  [..]
debugging only: pushes the dump as a list.
*/
PUSH(__dump_, LIST_NEWNODE, 0) /* variables */



#endif
