/*
    module  : sinh.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef SINH_C
#define SINH_C

/**
1650  sinh  :  F  ->  G
G is the hyperbolic sine of F.
*/
UFLOAT(sinh_, "sinh", sinh)



#endif
