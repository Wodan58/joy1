/*
    module  : char.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef CHAR_C
#define CHAR_C

/**
2340  char  :  X  ->  B
Tests whether X is a character.
*/
TYPE(char_, "char", ==, CHAR_)



#endif
