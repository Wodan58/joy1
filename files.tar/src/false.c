/*
    module  : false.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef FALSE_C
#define FALSE_C

/**
1000  false  :  ->  false
Pushes the value false.
*/
PUSH(false_, BOOLEAN_NEWNODE, 0)



#endif
