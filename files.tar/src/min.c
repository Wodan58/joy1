/*
    module  : min.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef MIN_C
#define MIN_C

/**
1820  min  :  N1 N2  ->  N
N is the minimum of numeric values N1 and N2.  Also supports float.
*/
MAXMIN(min_, "min", >)



#endif
