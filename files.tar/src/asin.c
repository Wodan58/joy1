/*
    module  : asin.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef ASIN_C
#define ASIN_C

/**
1500  asin  :  F  ->  G
G is the arc sine of F.
*/
UFLOAT(asin_, "asin", asin)



#endif
