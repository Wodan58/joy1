/*
    module  : some.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef SOME_C
#define SOME_C

/**
2870  some  :  A [B]  ->  X
Applies test B to members of aggregate A, X = true if some pass.
*/
SOMEALL(some_, "some", 0)



#endif
