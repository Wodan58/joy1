/*
    module  : echo.c
    version : 1.2
    date    : 04/11/22
*/
#ifndef ECHO_C
#define ECHO_C

/**
1120  echo  :  ->  I
Pushes value of echo flag, I = 0..3.
*/
PUSH(echo_, INTEGER_NEWNODE, env->echoflag)



#endif
