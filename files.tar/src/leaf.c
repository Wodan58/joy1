/*
    module  : leaf.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef LEAF_C
#define LEAF_C

/**
2390  leaf  :  X  ->  B
Tests whether X is not a list.
*/
TYPE(leaf_, "leaf", !=, LIST_)



#endif
