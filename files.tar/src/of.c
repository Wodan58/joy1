/*
    module  : of.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef OF_C
#define OF_C

/**
2080  of  :  I A  ->  X
X (= A[I]) is the I-th member of aggregate A.
*/
OF_AT(of_, "of", env->stck, nextnode1(env->stck))



#endif
