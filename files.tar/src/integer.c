/*
    module  : integer.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef INTEGER_C
#define INTEGER_C

/**
2330  integer  :  X  ->  B
Tests whether X is an integer.
*/
TYPE(integer_, "integer", ==, INTEGER_)



#endif
