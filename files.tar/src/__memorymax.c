/*
    module  : __memorymax.c
    version : 1.2
    date    : 05/03/22
*/
#ifndef __MEMORYMAX_C
#define __MEMORYMAX_C

/**
1160  __memorymax  :  ->  I
Pushes value of total size of memory.
*/
PUBLIC void __memorymax_(pEnv env)
{
    my_memorymax(env);
}
#endif
