/*
    module  : undeferror.c
    version : 1.2
    date    : 04/11/22
*/
#ifndef UNDEFERROR_C
#define UNDEFERROR_C

/**
1100  undeferror  :  ->  I
Pushes current value of undefined-is-error flag.
*/
PUSH(undeferror_, INTEGER_NEWNODE, env->undeferror)



#endif
