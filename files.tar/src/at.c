/*
    module  : at.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef AT_C
#define AT_C

/**
2070  at  :  A I  ->  X
X (= A[I]) is the member of A at position I.
*/
OF_AT(at_, "at", nextnode1(env->stck), env->stck)



#endif
