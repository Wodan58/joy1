/*
    module  : app3.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef APP3_C
#define APP3_C

/**
2560  app3  :  X1 X2 X3 [P]  ->  R1 R2 R3
Obsolescent.  == unary3
*/
PRIVATE void app3_(pEnv env) { unary3_(env); }



#endif
