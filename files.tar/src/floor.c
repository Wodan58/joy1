/*
    module  : floor.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef FLOOR_C
#define FLOOR_C

/**
1570  floor  :  F  ->  G
G is the floor of F.
*/
UFLOAT(floor_, "floor", floor)



#endif
