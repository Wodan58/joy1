/*
    module  : stdin.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef STDIN_C
#define STDIN_C

/**
1170  stdin  :  ->  S
Pushes the standard input stream.
*/
PUSH(stdin_, FILE_NEWNODE, stdin)



#endif
