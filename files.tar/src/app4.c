/*
    module  : app4.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef APP4_C
#define APP4_C

/**
2570  app4  :  X1 X2 X3 X4 [P]  ->  R1 R2 R3 R4
Obsolescent.  == unary4
*/
PRIVATE void app4_(pEnv env) { unary4_(env); }



#endif
