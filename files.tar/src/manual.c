/*
    module  : manual.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef MANUAL_C
#define MANUAL_C

#include "manual.h"

/**
2950  manual  :  ->
Writes this manual of all Joy primitives to output file.
*/
PRIVATE void manual_(pEnv env) { make_manual(0); }



#endif
