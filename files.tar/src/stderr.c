/*
    module  : stderr.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef STDERR_C
#define STDERR_C

/**
1190  stderr  :  ->  S
Pushes the standard error stream.
*/
PUSH(stderr_, FILE_NEWNODE, stderr)



#endif
