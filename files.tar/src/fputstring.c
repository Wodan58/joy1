/*
    module  : fputstring.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef FPUTSTRING_C
#define FPUTSTRING_C

/**
1980  fputstring  :  S "abc.."  ->  S
== fputchars, as a temporary alternative.
*/
PRIVATE void fputstring_(pEnv env) { fputchars_(env); }



#endif
