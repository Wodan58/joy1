/*
    module  : chr.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef CHR_C
#define CHR_C

/**
1470  chr  :  I  ->  C
C is the character whose Ascii value is integer I (or logical or character).
*/
ORDCHR(chr_, "chr", CHAR_NEWNODE)



#endif
