/*
    module  : float.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef FLOAT_C
#define FLOAT_C

/**
2410  float  :  R  ->  B
Tests whether R is a float.
*/
TYPE(float_, "float", ==, FLOAT_)



#endif
