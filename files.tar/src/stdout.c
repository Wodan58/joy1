/*
    module  : stdout.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef STDOUT_C
#define STDOUT_C

/**
1180  stdout  :  ->  S
Pushes the standard output stream.
*/
PUSH(stdout_, FILE_NEWNODE, stdout)



#endif
