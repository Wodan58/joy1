/*
    module  : popd.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef POPD_C
#define POPD_C

/**
1260  popd  :  Y Z  ->  Z
As if defined by:   popd  ==  [pop] dip
*/
DIPPED(popd_, "popd", TWOPARAMS, pop_)



#endif
