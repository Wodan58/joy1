/*
    module  : __html_manual.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef __HTML_MANUAL_C
#define __HTML_MANUAL_C

#include "manual.h"

/**
2960  __html_manual  :  ->
Writes this manual of all Joy primitives to output file in HTML style.
*/
PRIVATE void __html_manual_(pEnv env) { make_manual(1); }



#endif
