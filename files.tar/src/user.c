/*
    module  : user.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef USER_C
#define USER_C

/**
2400  user  :  X  ->  B
Tests whether X is a user-defined symbol.
*/
TYPE(user_, "user", ==, USR_)



#endif
