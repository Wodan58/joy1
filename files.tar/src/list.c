/*
    module  : list.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef LIST_C
#define LIST_C

/**
2380  list  :  X  ->  B
Tests whether X is a list.
*/
TYPE(list_, "list", ==, LIST_)



#endif
