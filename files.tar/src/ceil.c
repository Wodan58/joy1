/*
    module  : ceil.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef CEIL_C
#define CEIL_C

/**
1530  ceil  :  F  ->  G
G is the float ceiling of F.
*/
UFLOAT(ceil_, "ceil", ceil)



#endif
