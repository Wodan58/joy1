/*
    module  : succ.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef SUCC_C
#define SUCC_C

/**
1800  succ  :  M  ->  N
Numeric N is the successor of numeric M.
*/
PREDSUCC(succ_, "succ", +)



#endif
