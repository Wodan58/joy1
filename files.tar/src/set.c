/*
    module  : set.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef SET_C
#define SET_C

/**
2360  set  :  X  ->  B
Tests whether X is a set.
*/
TYPE(set_, "set", ==, SET_)



#endif
