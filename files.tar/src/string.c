/*
    module  : string.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef STRING_C
#define STRING_C

/**
2370  string  :  X  ->  B
Tests whether X is a string.
*/
TYPE(string_, "string", ==, STRING_)



#endif
