/*
    module  : sin.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef SIN_C
#define SIN_C

/**
1640  sin  :  F  ->  G
G is the sine of F.
*/
UFLOAT(sin_, "sin", sin)



#endif
