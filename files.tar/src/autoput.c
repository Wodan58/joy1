/*
    module  : autoput.c
    version : 1.2
    date    : 04/11/22
*/
#ifndef AUTOPUT_C
#define AUTOPUT_C

/**
1090  autoput  :  ->  I
Pushes current value of flag for automatic output, I = 0..2.
*/
PUSH(autoput_, INTEGER_NEWNODE, env->autoput)



#endif
