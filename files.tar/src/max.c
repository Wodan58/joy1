/*
    module  : max.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef MAX_C
#define MAX_C

/**
1810  max  :  N1 N2  ->  N
N is the maximum of numeric values N1 and N2.  Also supports float.
*/
MAXMIN(max_, "max", <)



#endif
