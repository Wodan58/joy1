/*
    module  : in.c
    version : 1.1
    date    : 05/21/21
*/
#ifndef IN_C
#define IN_C

#include "compare.h"

/**
2310  in  :  X A  ->  B
Tests whether X is a member of aggregate A.
*/
INHAS(in_, "in", env->stck, nextnode1(env->stck))



#endif
